
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>FTTH - Mapa Completo</title>
  <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
  <link rel="stylesheet" href="css/estilos.css" />
</head>
<body>
  <div id="topbar">
    <input type="text" id="busqueda" placeholder="🔍 Buscar cliente por nombre o PPPoE..." />
    <select id="filtroNAP"><option value="">📦 Filtrar por NAP</option></select>
    <select id="filtroEstado">
      <option value="">📶 Todos</option>
      <option value="online">🟢 Conectado</option>
      <option value="offline">🔴 Desconectado</option>
    </select>
  </div>
  <div id="mapa"></div>

  <div id="modal" class="modal">
    <div class="modal-content">
      <span id="cerrar" class="close">&times;</span>
      <h3>✏️ Editar Cliente</h3>
      <form id="formEditar">
        <input type="hidden" id="pppoe" />
        <label for="nombre">Nombre:</label><br>
        <input type="text" id="nombre"><br><br>
        <label for="nap">Asignar a Caja NAP:</label><br>
        <select id="nap"></select><br><br>
        <button type="submit">Guardar Cambios</button>
      </form>
    </div>
  </div>

  <script defer src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
  <script defer src="js/mapa.js"></script>
</body>
</html>
