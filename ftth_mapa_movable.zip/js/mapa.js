
document.addEventListener("DOMContentLoaded", () => {
  let mapa, datosGlobal = [], estadoClientes = {}, marcadores = [], lineas = [];

  async function cargarDatos() {
    const datos = await fetch('api/datos.json').then(r => r.json());
    const estados = await fetch('api/get_estado.php').then(r => r.json());
    datosGlobal = datos;
    estadoClientes = estados;
    cargarMapa();
    cargarFiltros();
  }

  function cargarMapa() {
    if (!mapa) {
      mapa = L.map('mapa');
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(mapa);
    }

    marcadores.forEach(m => mapa.removeLayer(m));
    lineas.forEach(l => mapa.removeLayer(l));
    marcadores = [];
    lineas = [];

    const bounds = [];

    datosGlobal.forEach(nap => {
      const iconoNap = L.icon({ iconUrl: 'icons/nap_icon.png', iconSize: [32,32], iconAnchor:[16,16] });
      const mNap = L.marker([nap.lat, nap.lng], { icon: iconoNap }).addTo(mapa)
        .bindPopup(`<b>${nap.nombre}</b>`);
      marcadores.push(mNap);
      bounds.push([nap.lat, nap.lng]);

      nap.clientes.forEach(cli => {
        const estado = estadoClientes[cli.pppoe] || {};
        const conectado = estado.online || false;
        const moroso = estado.moroso || false;
        const ip = estado.ip || "N/A";

        if (!pasaFiltros(cli, nap, conectado)) return;

        const icono = L.icon({
          iconUrl: moroso ? 'icons/cliente_moroso.png' : conectado ? 'icons/cliente_on.png' : 'icons/cliente_off.png',
          iconSize: [24, 24], iconAnchor: [12, 12]
        });

        const popup = `
        <div style='font-size:14px'>
          <b>👤 Cliente:</b> ${cli.nombre}<br>
          <b>📡 PPPoE:</b> ${cli.pppoe}<br>
          <b>🌐 IP:</b> ${ip}<br>
          <b>📦 NAP:</b> ${nap.nombre}<br>
          <b>📶 Estado:</b> ${conectado ? '🟢 Conectado' : '🔴 Desconectado'}<br>
          <b>💸 Deuda:</b> ${moroso ? "MOROSO 🔒" : "Al día ✅"}<br>
          <button onclick="abrirModal('${cli.pppoe}', '${cli.nombre}', '${nap.nap_id}')">✏️ Editar</button>
        </div>`;

        const marker = L.marker([cli.lat, cli.lng], {
          icon: icono,
          draggable: true
        }).addTo(mapa).bindPopup(popup);

        marker.on('dragend', async (e) => {
          const nuevaLatLng = e.target.getLatLng();
          cli.lat = nuevaLatLng.lat;
          cli.lng = nuevaLatLng.lng;
          await guardarPosicion(cli.pppoe, nuevaLatLng.lat, nuevaLatLng.lng);
        });

        const linea = L.polyline([[cli.lat, cli.lng], [nap.lat, nap.lng]], {
          color: 'blue', weight: 2, opacity: 0.7, dashArray: '5,5'
        }).addTo(mapa);

        marcadores.push(marker);
        lineas.push(linea);
        bounds.push([cli.lat, cli.lng]);
      });
    });

    if (bounds.length > 0) mapa.fitBounds(bounds, { padding: [50, 50] });
  }

  async function guardarPosicion(pppoe, lat, lng) {
    await fetch("api/guardar_posicion.php", {
      method: "POST",
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ pppoe, lat, lng })
    });
  }

  function pasaFiltros(cli, nap, conectado) {
    const q = document.getElementById("busqueda").value.toLowerCase();
    const fNAP = document.getElementById("filtroNAP").value;
    const fEstado = document.getElementById("filtroEstado").value;
    if (q && !cli.nombre.toLowerCase().includes(q) && !cli.pppoe.toLowerCase().includes(q)) return false;
    if (fNAP && nap.nap_id !== fNAP) return false;
    if (fEstado === "online" && !conectado) return false;
    if (fEstado === "offline" && conectado) return false;
    return true;
  }

  function cargarFiltros() {
    const selectNAP = document.getElementById("filtroNAP");
    selectNAP.innerHTML = '<option value="">📦 Filtrar por NAP</option>';
    datosGlobal.forEach(nap => {
      const opt = document.createElement("option");
      opt.value = nap.nap_id;
      opt.textContent = nap.nombre;
      selectNAP.appendChild(opt);
    });
  }

  function abrirModal(pppoe, nombre, nap_id) {
    document.getElementById("modal").style.display = "block";
    document.getElementById("pppoe").value = pppoe;
    document.getElementById("nombre").value = nombre;

    const select = document.getElementById("nap");
    select.innerHTML = "";
    datosGlobal.forEach(nap => {
      const usados = nap.clientes.length;
      const libre = usados < nap.capacidad;
      const opt = document.createElement("option");
      opt.value = nap.nap_id;
      opt.textContent = `${nap.nombre} (${usados}/${nap.capacidad})`;
      if (!libre) opt.disabled = true;
      if (nap.nap_id === nap_id) opt.selected = true;
      select.appendChild(opt);
    });
  }

  document.getElementById("cerrar").onclick = () => {
    document.getElementById("modal").style.display = "none";
  };

  document.getElementById("formEditar").onsubmit = async (e) => {
    e.preventDefault();
    const pppoe = document.getElementById("pppoe").value;
    const nombre = document.getElementById("nombre").value;
    const nap_id = document.getElementById("nap").value;
    const resp = await fetch("api/guardar_edicion.php", {
      method: "POST",
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ pppoe, nombre, nap_id })
    });
    const res = await resp.json();
    if (res.status === "ok") location.reload();
  };

  document.getElementById("busqueda").oninput = cargarMapa;
  document.getElementById("filtroNAP").onchange = cargarMapa;
  document.getElementById("filtroEstado").onchange = cargarMapa;

  cargarDatos();
  setInterval(cargarDatos, 300000);
});
